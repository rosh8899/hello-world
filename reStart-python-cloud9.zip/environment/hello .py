
a = "hello world"
print ("hello world")
